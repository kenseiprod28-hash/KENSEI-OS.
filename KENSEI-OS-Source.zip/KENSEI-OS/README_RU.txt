KENSEI OS — Android MVP. Включает контент-план, задачи, команду, идеи. Данные хранятся локально на устройстве.
Сборка: GitHub Actions workflow Build KENSEI OS APK создаёт debug APK. Это прототип, не синхронизирует данные между телефонами.
